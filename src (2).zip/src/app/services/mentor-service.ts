import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';
import { Mentor } from '../model/mentor';
import { CompileShallowModuleMetadata } from '@angular/compiler';
import { FLAGS } from '@angular/core/src/render3/interfaces/view';





const httpOptions = {
    headers : new HttpHeaders({ 'content-type' : 'application/json'})
       }

       
@Injectable({
    providedIn: 'root'
  })
export class MentorService {
       
        constructor(private http : HttpClient){
      
        }

        updateMentor(mentor : Mentor) {
          console.log(mentor);
          return this.http.post('/server/mentor/updateMentor', mentor);
      }
        
        getMentorHistory(mentorId : number) {
       
          return this.http.get('/server/mentor/viewHistory/' + mentorId );
      }

      mentorRegister(mentor : Mentor) {
        return  this.http.post('/server/mentor/mentorRegister', mentor);
       
      }

      getMentorLoginCredentials(email : String , password : String) {
       // console.log(this.http.get('server/mentor/mentorLoginCheck'));
        return this.http.post<any>('server/mentor/mentorLoginCheck', { username: email, password: password })
        .pipe();
      }
    }