import { Component, OnInit, Output, EventEmitter } from '@angular/core';



@Component({
    selector: 'welcome',
    templateUrl: './welcome.component.html'
})
export class WelcomeComponent implements OnInit{
flag   : boolean;

   
   
  
    ngOnInit(): void {
      
    }
  
}