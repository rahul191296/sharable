package com.cognizant.service.interf;

import com.cognizant.model.AdminModel;

public interface AdminService {

	boolean registerAdminService(AdminModel adminModel);
}
