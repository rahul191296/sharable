package com.cognizant.dao.interf;

import com.cognizant.entity.MentorEntity;

public interface MentorDao {
	boolean persistMentor(MentorEntity mentor);
}
