import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginStatusService } from '../../login-status-service';
import { AppComponent } from '../../app.component';
import { Router } from '@angular/router';
import { MentorService } from 'src/app/services/mentor-service';
import { first } from 'rxjs/operators';


@Component({
    selector: 'mentor-login',
    templateUrl: './mentor-login.component.html'
})
export class MentorLoginComponent implements OnInit{
  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }
  @ViewChild('f', {  }) loginForm: NgForm;

   public mentorLoginStatus;
   // :boolean = false;
  
 
  constructor(private router: Router ,private loginStatusService : LoginStatusService , public callToApp : AppComponent , private mentorService : MentorService) {

  }
     
setLoginStatus()  {
 
this.loginStatusService. setMentorLoginStatus(this.mentorLoginStatus);
}

onSubmit() {
//  this.mentorService.getMentorLoginCredentials(this.loginForm.value.email, this.loginForm.value.password) .pipe(first())
 // .subscribe(
  //  data => { this.mentorLoginStatus = data},
  //  err =>console.log(this.mentorLoginStatus)
 // ); 
 this.mentorLoginStatus = true;
//  if(this.mentorLoginStatus=="false"){
 //   this.router.navigate(['/mentor-menu']);
  //}
 
 // if(this.mentorLoginStatus) {
 //console.log(this.mentorLoginStatus);
 //}
    
    
 this.mentorLoginStatus = true;
 // this.mentor.email = this.loginForm.value.email;
  
 //this.mentor.email = this.loginForm.value.password;
   
   this.setLoginStatus();

   this.callToApp.fromLogin();
 if(this. mentorLoginStatus = true ) {
    this.router.navigate(['/mentor-menu']);
    }
    
  }
      
  
    
  
}
    
  
    




    
     
    