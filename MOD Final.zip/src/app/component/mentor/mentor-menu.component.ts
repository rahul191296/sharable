import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'mentor-menu',
    templateUrl: './mentor-menu.component.html'
})
export class MentorMenuComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}