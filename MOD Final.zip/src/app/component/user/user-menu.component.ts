import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'user-menu',
    templateUrl: './user-menu.component.html'
})
export class UserMenuComponent implements OnInit{
    ngOnInit(): void {
      
    }
  

    
}