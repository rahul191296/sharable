export class Training {
    trainingId : number ;
    userId : number;
	mentorId : number;
	fees : number;
	rating : number;
	status : String;
	commission : number;
	
    
}