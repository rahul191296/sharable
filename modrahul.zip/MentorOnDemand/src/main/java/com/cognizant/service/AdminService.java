package com.cognizant.service;

import com.cognizant.model.AdminModel;

public interface AdminService {

	boolean registerAdminService(AdminModel adminModel);
}
