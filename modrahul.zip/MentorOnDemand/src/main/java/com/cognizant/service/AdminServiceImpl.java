package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDao;
import com.cognizant.entity.AdminEntity;
import com.cognizant.model.AdminModel;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminDao adminDao;
		@Override
	public boolean registerAdminService(AdminModel adminModel) {
		AdminEntity admin=adminModel.adminModelToEntity(adminModel);
		return adminDao.registerAdmin(admin);
	}
	
}
