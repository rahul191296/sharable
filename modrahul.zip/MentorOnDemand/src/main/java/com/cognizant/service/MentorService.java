package com.cognizant.service;

import com.cognizant.model.MentorModel;

public interface MentorService {

	boolean registerMentor(MentorModel mentorModel);
}
