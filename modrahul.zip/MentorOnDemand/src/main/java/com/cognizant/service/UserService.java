package com.cognizant.service;

import com.cognizant.model.UserModel;

public interface UserService {
	
	boolean registerUser(UserModel userModel);

}
