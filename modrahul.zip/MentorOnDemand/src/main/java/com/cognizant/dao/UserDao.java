package com.cognizant.dao;

import com.cognizant.entity.UserEntity;

public interface UserDao {
	
	boolean persistUser(UserEntity user);

}
