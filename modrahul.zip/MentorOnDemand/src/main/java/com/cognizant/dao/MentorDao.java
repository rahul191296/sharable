package com.cognizant.dao;

import com.cognizant.entity.MentorEntity;

public interface MentorDao {
    boolean persistMentor(MentorEntity mentor); 
}
