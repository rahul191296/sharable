package com.cognizant.dao;

import com.cognizant.entity.AdminEntity;

public interface AdminDao {

	boolean registerAdmin(AdminEntity admin); 

}
