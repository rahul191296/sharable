package com.cognizant.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cognizant.entity.AdminEntity;


@Repository
public class AdminDaoImpl implements AdminDao{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public boolean registerAdmin(AdminEntity admin) {
		manager.persist(admin);
		return true;
	}


}
