package com.cognizant.model;



import com.cognizant.entity.AdminEntity;


public class AdminModel {
	
	private int adminId;
	   
	
	private String password;
	
	AdminModel adminModel=null;
	AdminEntity admin=null;
    
	
	
	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public AdminModel adminEntityToModel(AdminEntity admin){
    adminModel = new AdminModel();
	adminModel.adminId=admin.getAdminId();
	adminModel.password=admin.getPassword();
	
               return adminModel;

                       }

    public AdminEntity adminModelToEntity(AdminModel adminModel){

	    admin=new AdminEntity();
		admin.setAdminId(adminModel.getAdminId());
		admin.setPassword(adminModel.getPassword());
                  return admin;

}

}
