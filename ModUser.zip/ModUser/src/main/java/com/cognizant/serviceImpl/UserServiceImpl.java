package com.cognizant.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.convertor.MentorConvertor;
import com.cognizant.convertor.UserConvertor;
import com.cognizant.entity.MentorEntity;
import com.cognizant.entity.UserEntity;
import com.cognizant.interfac.UserDao;
import com.cognizant.interfac.UserService;
import com.cognizant.model.MentorModel;
import com.cognizant.model.UserModel;


@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	UserConvertor userConvertor = new UserConvertor();
	MentorConvertor mentorConvertor = new MentorConvertor();

	@Override
	public boolean registerUser(UserModel userModel) {
		UserEntity user = userConvertor.userModelToEntity(userModel);
		return userDao.persistUser(user);
	}

	@Override
	public MentorModel searchMentor(String technology, String timingSlot) {
		
		MentorEntity mentorList = userDao.getMentor(technology,timingSlot);
		
		return mentorConvertor.mentorEntityToModel(mentorList);
		
	}

}
