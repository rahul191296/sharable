package com.cognizant.service.interf;

import com.cognizant.model.UserModel;

public interface UserService {

	boolean registerUser(UserModel userModel);

}
