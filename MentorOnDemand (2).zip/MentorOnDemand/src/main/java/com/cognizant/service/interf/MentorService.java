package com.cognizant.service.interf;

import com.cognizant.model.MentorModel;

public interface MentorService {

	boolean registerMentor(MentorModel mentorModel);
}
