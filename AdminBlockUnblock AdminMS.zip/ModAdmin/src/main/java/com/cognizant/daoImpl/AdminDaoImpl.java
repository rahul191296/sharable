package com.cognizant.daoImpl;

import java.io.Console;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;



import com.cognizant.interfac.AdminDao;



@Repository
public class AdminDaoImpl implements AdminDao {

	@PersistenceContext
	private EntityManager manager;

	@Transactional
	@Override
	public boolean blockUser(int userId) {
		int userStatus = 0;
		 
		Query query = manager.createNativeQuery("update  Users_Table set user_Status=:userStatus where user_Id=:userId");
		query.setParameter("userStatus", "Block");
		query.setParameter("userId", userId);
		userStatus = query.executeUpdate();
		
		if(userStatus == 1) 
	    return true;
	  	else
			return false;
	}

	@Transactional
	@Override
	public boolean UnblockUser(int userId) {
		
		int userStatus = 0;
		Query query = manager.createNativeQuery("update  Users_Table set user_Status=:userStatus where user_Id=:userId");
		query.setParameter("userStatus", "Unblock");
		query.setParameter("userId", userId);
		userStatus = query.executeUpdate();
		if(userStatus == 1) 
		    return true;
		else
			return false;
	}

	@Transactional
	@Override
	public boolean blockMentor(int mentorId) {
		
		int mentorStatus = 0;
		Query query = manager.createNativeQuery("update  Mentor_Table set mentor_Status=:mentorStatus where mentor_Id=:mentorId");
		query.setParameter("mentorStatus", "Block");
		query.setParameter("mentorId", mentorId);
		mentorStatus = query.executeUpdate();
		if(mentorStatus == 1) 
		    return true;
		else
			return false;
	}

	@Transactional
	@Override
	public boolean UnblockMentor(int mentorId) {
		
		int mentorStatus = 0;
		Query query = manager.createNativeQuery("update  Mentor_Table set mentor_Status=:mentorStatus where mentor_Id=:mentorId");
		query.setParameter("mentorStatus", "Unblock");
		query.setParameter("mentorId", mentorId);
		mentorStatus = query.executeUpdate();
		if(mentorStatus == 1) 
		    return true;
		else
			return false;
	}

	
}
