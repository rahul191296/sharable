package com.cognizant.dao.interf;

import com.cognizant.entity.AdminEntity;

public interface AdminDao {

	boolean registerAdmin(AdminEntity admin);

}
